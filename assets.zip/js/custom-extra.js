(function($) {
  "use strict";



})(jQuery);